Airplane = {
  initialize: function(pong) {
    this.pong = pong;

  }, // initialize


}
